<!DOCTYPE html>
<html>
<head>
    <title>Edit About</title>
</head>
<body>
    <h1>Edit About</h1>

    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('about.update')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" value="<?php echo e($about->title); ?>" required>
        </div>

        <div>
            <label for="content">Content:</label>
            <textarea id="content" name="content" required><?php echo e($about->content); ?></textarea>
        </div>

        <div>
            <label for="image">Image:</label>
            <input type="file" id="image" name="image">
            <?php if($about->image): ?>
                <img src="<?php echo e(Storage::url($about->image)); ?>" alt="About Image" style="max-width: 200px;">
            <?php endif; ?>
        </div>

        <div>
            <button type="submit">Update</button>
        </div>
    </form>
</body>
</html>
<?php /**PATH C:\Users\SUPPORT\Documents\project laravel\company-profile\resources\views/about/edit.blade.php ENDPATH**/ ?>